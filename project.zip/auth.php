<?
	include('config.php');
	$username = $_POST['username'];
	$password = $_POST['password'];

	$q = mysqli_query($con, "SELECT * FROM cinema_owners WHERE username = '$username' and password = '$password'");
	if (mysqli_num_rows($q) > 0) {
		session_start();
		$_SESSION['login'] = $username;
	}
?>