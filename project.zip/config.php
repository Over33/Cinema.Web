<?
	$db_server = 'localhost';
	$db_username = 'root';
	$db_password = 'root';
	$db_name = 'prototype';
	
	$con = mysqli_connect($db_server, $db_username, $db_password, $db_name);
	if (!$con) {
		echo("MySQL Connection error: ". mysqli_error($con));
	} else {
		mysqli_set_charset($con, "utf8");
	}
?>