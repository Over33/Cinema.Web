-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июн 02 2018 г., 08:10
-- Версия сервера: 5.7.22-log
-- Версия PHP: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `prototype`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cinema_buildings`
--

CREATE TABLE `cinema_buildings` (
  `cinema_id` int(10) NOT NULL,
  `cinema_name` varchar(500) NOT NULL,
  `owner_id` int(10) NOT NULL,
  `cinema_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cinema_buildings`
--

INSERT INTO `cinema_buildings` (`cinema_id`, `cinema_name`, `owner_id`, `cinema_address`) VALUES
(1, 'Киноплекс - Кремль', 1, 'Красная площадь, 1'),
(2, 'Киноплекс - Мясницкая', 1, 'Мясницкая, 20');

-- --------------------------------------------------------

--
-- Структура таблицы `cinema_halls`
--

CREATE TABLE `cinema_halls` (
  `hall_id` int(10) NOT NULL,
  `cinema_id` int(10) NOT NULL,
  `hall_name` varchar(500) NOT NULL,
  `capacity` int(11) NOT NULL,
  `rows_count` int(11) NOT NULL,
  `cols_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cinema_halls`
--

INSERT INTO `cinema_halls` (`hall_id`, `cinema_id`, `hall_name`, `capacity`, `rows_count`, `cols_count`) VALUES
(1, 1, 'Красный зал', 192, 12, 16),
(2, 1, 'Синий зал', 192, 12, 16);

-- --------------------------------------------------------

--
-- Структура таблицы `cinema_halls_geometry`
--

CREATE TABLE `cinema_halls_geometry` (
  `hall_id` int(11) NOT NULL,
  `row_id` int(11) NOT NULL,
  `col_id` int(11) NOT NULL,
  `place_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cinema_owners`
--

CREATE TABLE `cinema_owners` (
  `owner_id` int(10) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cinema_owners`
--

INSERT INTO `cinema_owners` (`owner_id`, `username`, `password`, `email`) VALUES
(1, 'Roman', '12345', '');

-- --------------------------------------------------------

--
-- Структура таблицы `cinema_timetable`
--

CREATE TABLE `cinema_timetable` (
  `session_id` int(11) NOT NULL,
  `hall_id` int(11) NOT NULL,
  `film_id` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `duration_minutes` int(11) NOT NULL,
  `session_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cinema_timetable`
--

INSERT INTO `cinema_timetable` (`session_id`, `hall_id`, `film_id`, `start_time`, `duration_minutes`, `session_type`) VALUES
(1, 1, 1, '2018-06-29 12:40:00', 150, 'IMAX 3D');

-- --------------------------------------------------------

--
-- Структура таблицы `films`
--

CREATE TABLE `films` (
  `film_id` int(11) NOT NULL,
  `film_name` varchar(100) NOT NULL,
  `film_description` varchar(1000) NOT NULL,
  `poster_url` varchar(500) NOT NULL,
  `duration_minuts` int(11) NOT NULL,
  `genres` varchar(500) NOT NULL,
  `min_age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `films`
--

INSERT INTO `films` (`film_id`, `film_name`, `film_description`, `poster_url`, `duration_minuts`, `genres`, `min_age`) VALUES
(1, 'Пираты Карибского моря: Проклятие Чёрной жемчужины', 'Приключенческий фильм о пиратах, действие которого разворачивается на Карибах в первой половине XVIII века. Фильм был поставлен режиссёром Гором Вербински и спродюсирован Джерри Брукхаймером. Идея картины пришла к создателям под впечатлением от одноимённого тематического водного аттракциона в Диснейленде.', 'jack.jpg', 120, 'Экшн, Приключенческий, Фэнтэзи. 13+', 13),
(2, 'Криминальное Чтиво', 'Кинофильм режиссёра Квентина Тарантино. Сюжет фильма нелинеен, как и почти во всех остальных работах Тарантино. Этот приём стал чрезвычайно популярен, породив множество подражаний во второй половине 1990-х.', 'pulp.jpg', 120, 'чёрная комедия', 16),
(3, 'Титаник', 'Американский фильм-катастрофа 1997 года, снятый режиссёром Джеймсом Кэмероном, в котором показана гибель легендарного лайнера «Титаник». Это седьмой фильм режиссёра. Главные роли в фильме исполнили Кейт Уинслет (Роуз Дьюитт Бьюкейтер) и Леонардо Ди Каприо (Джек Доусон)', 'leo.jpg', 120, 'Фильм-катастрофа, Мелодрама, Драма, 16+', 16);

-- --------------------------------------------------------

--
-- Структура таблицы `sessions_cost`
--

CREATE TABLE `sessions_cost` (
  `session_id` int(11) NOT NULL,
  `visitor_category` varchar(100) NOT NULL,
  `cost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cinema_buildings`
--
ALTER TABLE `cinema_buildings`
  ADD PRIMARY KEY (`cinema_id`);

--
-- Индексы таблицы `cinema_halls`
--
ALTER TABLE `cinema_halls`
  ADD PRIMARY KEY (`hall_id`);

--
-- Индексы таблицы `cinema_owners`
--
ALTER TABLE `cinema_owners`
  ADD PRIMARY KEY (`owner_id`),
  ADD UNIQUE KEY `username_index` (`username`);

--
-- Индексы таблицы `cinema_timetable`
--
ALTER TABLE `cinema_timetable`
  ADD PRIMARY KEY (`session_id`);

--
-- Индексы таблицы `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`film_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cinema_buildings`
--
ALTER TABLE `cinema_buildings`
  MODIFY `cinema_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `cinema_halls`
--
ALTER TABLE `cinema_halls`
  MODIFY `hall_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `cinema_owners`
--
ALTER TABLE `cinema_owners`
  MODIFY `owner_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `cinema_timetable`
--
ALTER TABLE `cinema_timetable`
  MODIFY `session_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `films`
--
ALTER TABLE `films`
  MODIFY `film_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
