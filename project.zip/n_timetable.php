<?
	include('config.php');
	$hall_id = $_POST['hall_id'];
	$film_id = $_POST['film_id'];
	$start_time = $_POST['start_time'];
	$duration_minutes = $_POST['duration_minutes'];
	$session_type = $_POST['session_type'];
	
	
	$q = mysqli_query($con, "INSERT into cinema_timetable(hall_id, film_id, start_time, duration_minutes, session_type) VALUES ('$hall_id', '$film_id', '$start_time', 'duration_minutes', 'session_type') ");
?>