<?
	include('config.php');
	$film_name = $_POST['film_name'];
	$film_description = $_POST['film_description'];
	$poster_url = $_POST['poster_url'];
	$genre = $_POST['genre'];
	$duration_minuts = $_POST['duration_minuts'];
	$min_age = $_POST['min_age'];

	$q = mysqli_query($con, "INSERT into films(film_name, film_description, poster_url, genre, duration_minuts, min_age) VALUES ('$film_name', '$film_description', '$poster_url', '$genre', '$duration_minuts', '$min_age') ");
?>