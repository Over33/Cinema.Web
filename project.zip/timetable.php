<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Расписание сеансов</title>

  <!-- Bootstrap Grid -->
  <link rel="stylesheet" type="text/css" href="/media/assets/bootstrap-grid-only/css/grid12.css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

  <!-- Custom -->
  <link rel="stylesheet" type="text/css" href="/media/css/style.css">
</head>
<body>

  <div id="wrapper">

    <header id="header">
      <div class="header__top">
        <div class="container">
          <div class="header__top__logo">
            <h1>Cinema App Constructor</h1>
          </div>
          <nav class="header__top__menu">
            <ul>
              <li><a href="#">Регистрация</a></li>
			  <li><a href="auth_page.php">Войти</a></li>
            </ul>
          </nav>
        </div>
      </div>

      <div class="header__bottom">
        <div class="container">
          <nav>
            <ul>
              <li><a href="index.html">Главная</a></li>
              <li><a href="cinemas.php">Кинотеатры</a></li>
              <li><a href="halls.php">Залы</a></li>
              <li><a href="timetable.php">Сеансы</a></li>
              <li><a href="movies.php">Фильмы</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </header>

	<div class="block">
	  <h3>Ближайшие сеансы</h3>
	  <a href="timetable_new.php">Добавить новый</a>
	  
	  <?php
			include('config.php');
			$sessions = mysqli_query($con, "SELECT * FROM cinema_timetable");
		?>
		
		<?php
			while( $session = mysqli_fetch_assoc($sessions) )
			{
				?>
				    <div class="block__content">
						<div class="articles articles__vertical">
						<article class="article">
							<div class="article__info">
							<a href="#"><?php echo $session['session_id']; ?></a>
							<div class="article__info__meta">
							<small><a href="#"><?php echo 'HALL ID: ', $session['hall_id']; ?></a></small>
							<small><a href="#"><?php echo 'FILM ID: ', $session['film_id']; ?></a></small>
							<small><a href="#"><?php echo $session['start_time']; ?></a></small>
							<small><a href="#"><?php echo $session['duration_minutes']; ?></a></small>
							<small><a href="#"><?php echo $session['session_type']; ?></a></small>
							</div>
							</div>
						</article>
						</div>
					</div>
				<?php
			}
		?>
	</div>



  </div>

</body>
</html>