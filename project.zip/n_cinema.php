<?
	include('config.php');
	$cinema_name = $_POST['cinema_name'];
	$owner_id = $_POST['owner_id'];
	$cinema_address = $_POST['cinema_address'];
	
	
	$q = mysqli_query($con, "INSERT into cinema_timetable(cinema_name, owner_id, cinema_address) VALUES ('$cinema_name', '$owner_id', '$cinema_address') ");
?>