<?
	include('config.php');
	$username = $_POST['username'];
	$password = $_POST['password'];
	$email = $_POST['email'];
	
	$q = mysqli_query($con, "SELECT * FROM cinema_owners WHERE username = '$username' ");
	if (mysqli_num_rows($q) > 0) {
		echo("Пользователь с таким именем уже существует!");
		return;
	}
	
	$q = mysqli_query($con, "INSERT into cinema_owners(username, password, email) VALUES ('$username', '$password', '$email') ");
//	if ()
?>