<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Cinema App Constructor</title>

  <!-- Bootstrap Grid -->
  <link rel="stylesheet" type="text/css" href="/media/assets/bootstrap-grid-only/css/grid12.css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">

  <!-- Custom -->
  <link rel="stylesheet" type="text/css" href="/media/css/style.css">
</head>
<body>

  <div id="wrapper">

    <header id="header">
      <div class="header__top">
        <div class="container">
          <div class="header__top__logo">
            <h1>Cinema App Constructor</h1>
          </div>
          <nav class="header__top__menu">
            <ul>
              <li><a href="#">Регистрация</a></li>
			  <li><a href="auth_page.php">Войти</a></li>
            </ul>
          </nav>
        </div>
      </div>

      <div class="header__bottom">
        <div class="container">
          <nav>
            <ul>
              <li><a href="index.html">Главная</a></li>
              <li><a href="cinemas.php">Кинотеатры</a></li>
              <li><a href="halls.php">Залы</a></li>
              <li><a href="timetable.php">Сеансы</a></li>
              <li><a href="movies.php">Фильмы</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  </div>
  
  <div>
	<form method='post' action='auth.php'>
		<table>
		<tr>
			<td>Username:</td>
			<td><input name='username' required></input></td>
		</tr>
		<tr>
			<td>Password:</td>
			<td><input name='password' type='password' required></input></td>
		</tr>
		<tr>
			<td><center><input type='submit' value='Войти'></input></center></td>
		</tr>
	</form>
  </div>
</body>
</html>