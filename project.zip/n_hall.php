<?
	include('config.php');
	$cinema_id = $_POST['cinema_id'];
	$hall_name = $_POST['hall_name'];
	$capacity = $_POST['capacity'];
	$raws_count = $_POST['raws_count'];
	$cols_count = $_POST['cols_count'];
	
	
	
	$q = mysqli_query($con, "INSERT into cinema_timetable(cinema_id, hall_name, capacity, raws_count, cols_count) VALUES ('$cinema_id', '$hall_name', '$capacity', '$raws_count', '$cols_count') ");
?>